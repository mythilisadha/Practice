package com.example.restservice;

import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;

public class Inventory {


	public String productid;
	public  String prodName;
	public String UOM;
	public  Integer availQty;
	public LocalDate availDate;

	public Inventory(String productid, String prodName, String UOM, Integer availQty, LocalDate availDate) {
		this.productid = productid;
		this.prodName = prodName;
		this.UOM = UOM;
		this.availQty = availQty;
		this.availDate = availDate;
	}
	public Inventory () {
	}
	public String getProductid() {
		return productid;
	}

	public void setProductid(String productid) {
		this.productid = productid;
	}

	public String getProdName() {
		return prodName;
	}

	public void setProdName(String prodName) {
		this.prodName = prodName;
	}

	public String getUOM() {
		return UOM;
	}

	public void setUOM(String UOM) {
		this.UOM = UOM;
	}

	public Integer getAvailQty() {
		return availQty;
	}

	public void setAvailQty(Integer availQty) {
		this.availQty = availQty;
	}

	public LocalDate getAvailDate() {
		return availDate;
	}

	public void setAvailDate(LocalDate availDate) {
		this.availDate = availDate;
	}

}
