package com.example.restservice;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProblemsController {

	private static final String template = "Hello, %s!";
	private final AtomicLong counter = new AtomicLong();


	@GetMapping("/getInvPicture")
	public Inventory greeting(@RequestParam Inventory input) {
		List<Inventory> inventoryList = new ArrayList<>();
		inventoryList.add(new Inventory("Prod1","Shirt","EACH", 10, LocalDate.parse("2021-03-19")) );
		inventoryList.add(new Inventory("Prod1","Trousers","EACH", 20,LocalDate.parse("2021-03-21")));
		inventoryList.add(new Inventory("Prod1","Trousers","EACH", 20,LocalDate.parse("2021-03-29")));

		LocalDate lDate = LocalDate.parse("2021-03-19");
		LocalDate hDate = LocalDate.parse("2021-03-29");

		Inventory output = new Inventory();
		output.setProductid(input.getProductid());
		output.setProdName(input.getProdName());
		output.setAvailQty(0);
		for ( Inventory obj: inventoryList
			 ) {
			if(input.getAvailDate().compareTo(lDate) >= 0 && input.getAvailDate().compareTo(hDate)<=0 &&
			input.prodName == obj.prodName && input.productid == obj.productid) {
				output.setAvailQty(output.getAvailQty() + obj.getAvailQty());
			} else {
				break;
			}
		}

		return output;
	}
}
